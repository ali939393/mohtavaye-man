فایل‌های فونت ایران‌یکان را اینجا قرار دهید:
  iran_yekan_regular.ttf
  iran_yekan_bold.ttf
سپس فایل font_family_iranyekan.xml به‌صورت خودکار آن‌ها را شناسایی می‌کند.
(فایل‌های ttf به دلیل محدودیت لایسنس در مخزن قرار نگرفته‌اند.)
