package ir.omrano.mohtavayeman.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.omrano.mohtavayeman.data.ReminderStage
import ir.omrano.mohtavayeman.ui.OmranoButton
import ir.omrano.mohtavayeman.ui.OmranoCard
import ir.omrano.mohtavayeman.ui.SectionTitle
import ir.omrano.mohtavayeman.vm.ContentDetailViewModel
import ir.omrano.mohtavayeman.vm.ContentViewModel

/** صفحه جزئیات محتوا: چک‌لیست (پیش‌فرض + دلخواه) و یادآور دو مرحله‌ای */
@Composable
fun ContentDetailScreen(contentId: Long, onDismiss: () -> Unit) {
    val vm: ContentDetailViewModel = viewModel()
    LaunchedEffect(contentId) { vm.load(contentId) }
    val content by vm.content.collectAsState()
    val checklist by vm.checklist.collectAsState()
    val contentVm: ContentViewModel = viewModel()

    var newItem by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.background
        ) {
            val c = content ?: run {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                return@Dialog
            }
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Text(c.title, style = MaterialTheme.typography.titleLarge)
                if (c.description.isNotBlank())
                    Text(c.description, style = MaterialTheme.typography.bodyMedium)

                SectionTitle("چک‌لیست")
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(checklist, key = { it.id }) { item ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = item.done, onCheckedChange = { vm.toggle(item) })
                            Text(item.text, Modifier.weight(1f),
                                style = MaterialTheme.typography.bodyLarge)
                            if (!item.isDefault)
                                IconButton(onClick = { vm.remove(item) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "حذف")
                                }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = newItem, onValueChange = { newItem = it },
                        placeholder = { Text("آیتم دلخواه…") },
                        modifier = Modifier.weight(1f), singleLine = true)
                    Spacer(Modifier.width(8.dp))
                    OmranoButton("افزودن") {
                        vm.add(newItem); newItem = ""
                    }
                }

                SectionTitle("یادآور دو مرحله‌ای")
                ReminderEditor(
                    stage = ReminderStage.valueOf(c.reminderStage),
                    onStageChange = { stage ->
                        val updated = c.copy(reminderStage = stage.name)
                        contentVm.save(updated); vm.reschedule(updated)
                    })
                Spacer(Modifier.height(10.dp))
                OmranoButton("بستن", onClick = onDismiss, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
fun ReminderEditor(stage: ReminderStage, onStageChange: (ReminderStage) -> Unit) {
    Column {
        ReminderStage.entries.forEach { s ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = stage == s, onClick = { onStageChange(s) })
                Text(s.labelFa)
            }
        }
        Text(
            "مرحله اول: یک روز قبل صبح — مرحله دوم: روز انتشار عصر (قابل تنظیم در کد)",
            style = MaterialTheme.typography.labelMedium
        )
    }
}
