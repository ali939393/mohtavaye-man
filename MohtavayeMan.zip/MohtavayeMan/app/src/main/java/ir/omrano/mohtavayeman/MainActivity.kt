package ir.omrano.mohtavayeman

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import ir.omrano.mohtavayeman.ui.MohtavayeManAppScreen
import ir.omrano.mohtavayeman.ui.theme.MohtavayeManTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MohtavayeManTheme {
                MohtavayeManAppScreen()
            }
        }
    }
}
