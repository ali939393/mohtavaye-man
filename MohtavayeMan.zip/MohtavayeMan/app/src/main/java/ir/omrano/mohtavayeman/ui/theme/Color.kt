package ir.omrano.mohtavayeman.ui.theme

import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0B2447)
val NavyDark = Color(0xFF071B36)
val Orange = Color(0xFFF97B22)
val OrangeLight = Color(0xFFFFB84C)
val SurfaceLight = Color(0xFFF7F9FC)
