package ir.omrano.mohtavayeman.vm

import android.content.Context
import androidx.room.withTransaction
import ir.omrano.mohtavayeman.data.AppDatabase
import ir.omrano.mohtavayeman.data.ChecklistItem
import ir.omrano.mohtavayeman.data.Content
import ir.omrano.mohtavayeman.data.DefaultChecklist
import ir.omrano.mohtavayeman.data.Idea
import ir.omrano.mohtavayeman.data.ReminderStage
import ir.omrano.mohtavayeman.util.JalaliUtils
import ir.omrano.mohtavayeman.work.ReminderScheduler
import kotlinx.coroutines.flow.Flow

class ContentRepository(private val db: AppDatabase) {
    fun all(): Flow<List<Content>> = db.contentDao().observeAll()
    fun byId(id: Long): Flow<Content?> = db.contentDao().observeById(id)
    fun search(q: String): Flow<List<Content>> = db.contentDao().search(q)
    fun byJalaliMonth(y: Int, m: Int): Flow<List<Content>> = db.contentDao().observeByJalaliMonth(y, m)
    fun checklist(contentId: Long): Flow<List<ChecklistItem>> = db.checklistDao().observeForContent(contentId)

    suspend fun save(context: Context, content: Content, checklistTexts: List<String>? = null): Long {
        val id = if (content.id == 0L) {
            val newId = db.contentDao().insert(content)
            val items = (checklistTexts ?: DefaultChecklist.items).mapIndexed { i, t ->
                ChecklistItem(contentId = newId, text = t, isDefault = checklistTexts == null, order = i)
            }
            db.checklistDao().insertAll(items)
            newId
        } else {
            db.contentDao().update(content)
            content.id
        }
        scheduleReminders(context, db.contentDao().getById(id)!!)
        return id
    }

    /** زمان‌بندی یادآورهای دو مرحله‌ای بر اساس تنظیمات همان محتوا */
    suspend fun scheduleReminders(context: Context, content: Content) {
        ReminderScheduler.cancel(context, content.id)
        val stage = ReminderStage.valueOf(content.reminderStage)
        val y = content.publishYear ?: return
        val m = content.publishMonth ?: return
        val d = content.publishDay ?: return
        if (stage == ReminderStage.NONE) return
        if (stage == ReminderStage.STAGE1 || stage == ReminderStage.BOTH) {
            val millis = JalaliUtils.jalaliToMillis(y, m, d, content.reminder1Hour, 0)
            val trigger = millis - content.reminder1DaysBefore * 86_400_000L
            ReminderScheduler.schedule(context, content.id, content.title,
                content.reminder1DaysBefore, content.reminder1Hour, trigger, 1)
        }
        if (stage == ReminderStage.STAGE2 || stage == ReminderStage.BOTH) {
            val millis = JalaliUtils.jalaliToMillis(y, m, d, content.reminder2Hour, 0)
            val trigger = millis - content.reminder2DaysBefore * 86_400_000L
            ReminderScheduler.schedule(context, content.id, content.title,
                content.reminder2DaysBefore, content.reminder2Hour, trigger, 2)
        }
    }

    suspend fun delete(context: Context, content: Content) {
        ReminderScheduler.cancel(context, content.id)
        db.contentDao().delete(content)
    }

    suspend fun toggleItem(item: ChecklistItem) {
        db.checklistDao().update(item.copy(done = !item.done))
    }
    suspend fun addItem(contentId: Long, text: String) {
        db.checklistDao().insert(ChecklistItem(contentId = contentId, text = text, isDefault = false))
    }
    suspend fun removeItem(item: ChecklistItem) = db.checklistDao().delete(item)
}

class IdeaRepository(private val db: AppDatabase) {
    fun all(): Flow<List<Idea>> = db.ideaDao().observeAll()
    fun search(q: String): Flow<List<Idea>> = db.ideaDao().search(q)
    suspend fun quickAdd(text: String) {
        if (text.isNotBlank()) db.ideaDao().insert(Idea(text = text.trim()))
    }
    suspend fun delete(idea: Idea) = db.ideaDao().delete(idea)
}
