package ir.omrano.mohtavayeman.data

import androidx.room.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

enum class DayType { ACTIVE, REST }

enum class ReminderStage(val labelFa: String) {
    NONE("بدون یادآور"),
    STAGE1("مرحله اول"),
    STAGE2("مرحله دوم"),
    BOTH("هر دو مرحله");
}

@Entity(tableName = "contents")
data class Content(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    @ColumnInfo(name = "publish_year") val publishYear: Int? = null,
    @ColumnInfo(name = "publish_month") val publishMonth: Int? = null, // 1..12 جلالی
    @ColumnInfo(name = "publish_day") val publishDay: Int? = null,
    @ColumnInfo(name = "rest_day") val restDay: Boolean = false,
    /** تنظیم یادآور دو مرحله‌ای برای هر محتوا */
    @ColumnInfo(name = "reminder_stage") val reminderStage: String = ReminderStage.NONE.name,
    @ColumnInfo(name = "reminder1_days_before") val reminder1DaysBefore: Int = 1,
    @ColumnInfo(name = "reminder1_hour") val reminder1Hour: Int = 9,
    @ColumnInfo(name = "reminder2_days_before") val reminder2DaysBefore: Int = 0,
    @ColumnInfo(name = "reminder2_hour") val reminder2Hour: Int = 20,
    val createdAt: Long = System.currentTimeMillis(),
)

/** آیتم چک‌لیست؛ آیتم‌های پیش‌فرض هنگام ایجاد محتوا ساخته می‌شوند */
@Entity(tableName = "checklist_items", foreignKeys = [ForeignKey(
    entity = Content::class, parentColumns = ["id"], childColumns = ["contentId"], onDelete = ForeignKey.CASCADE
)], indices = [Index("contentId")])
data class ChecklistItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contentId: Long,
    val text: String,
    val done: Boolean = false,
    val isDefault: Boolean = false,
    val order: Int = 0,
)

@Entity(tableName = "ideas")
data class Idea(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val createdAt: Long = System.currentTimeMillis(),
)

object DefaultChecklist {
    val items = listOf(
        "تحقیق و ایده‌پردازی",
        "نوشتن متن یا سناریو",
        "تولید / ضبط محتوا",
        "ویرایش",
        "بازبینی نهایی",
        "انتشار",
    )
}

class ChecklistConverter {
    private val gson = Gson()
    private val type = object : TypeToken<List<String>>() {}.type
    @TypeConverter fun fromList(v: List<String>?): String = gson.toJson(v ?: emptyList())
    @TypeConverter fun toList(v: String): List<String> =
        try { gson.fromJson(v, type) } catch (e: Exception) { emptyList() }
}
