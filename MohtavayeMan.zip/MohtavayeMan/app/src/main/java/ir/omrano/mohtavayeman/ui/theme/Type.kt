package ir.omrano.mohtavayeman.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import ir.omrano.mohtavayeman.R

/**
 * فونت ایران‌یکان: فایل‌های ttf را در res/font قرار دهید (README.txt را ببینید).
 * در صورت نبود فایل، این خط را با FontFamily.Default جایگزین کنید.
 */
// val IranYekan = FontFamily(Font(R.font.iran_yekan_regular), Font(R.font.iran_yekan_bold, FontWeight.Bold))
val IranYekan = FontFamily.Default

val AppTypography = Typography().run {
    copy(
        titleLarge = TextStyle(fontFamily = IranYekan, fontWeight = FontWeight.Bold, fontSize = 22.sp),
        titleMedium = TextStyle(fontFamily = IranYekan, fontWeight = FontWeight.SemiBold, fontSize = 18.sp),
        bodyLarge = TextStyle(fontFamily = IranYekan, fontSize = 16.sp),
        bodyMedium = TextStyle(fontFamily = IranYekan, fontSize = 14.sp),
        labelMedium = TextStyle(fontFamily = IranYekan, fontSize = 12.sp),
    )
}
