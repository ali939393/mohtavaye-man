package ir.omrano.mohtavayeman.work

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import ir.omrano.mohtavayeman.R
import ir.omrano.mohtavayeman.data.AppDatabase
import java.util.concurrent.TimeUnit

/** کارگر نمایش نوتیفیکیشن یادآور */
class ReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val contentId = inputData.getLong(KEY_CONTENT_ID, -1)
        val stage = inputData.getInt(KEY_STAGE, 1)
        if (contentId == -1L) return Result.failure()
        val db = AppDatabase.getInstance(applicationContext)
        val content = db.contentDao().getById(contentId) ?: return Result.success()
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = ReminderScheduler.CHANNEL_ID
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(channel,
                    applicationContext.getString(R.string.notify_channel),
                    NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val notif = NotificationCompat.Builder(applicationContext, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("یادآور مرحله $stage")
            .setContentText(content.title)
            .setAutoCancel(true)
            .build()
        nm.notify((contentId * 10 + stage).toInt(), notif)
        return Result.success()
    }

    companion object {
        const val KEY_CONTENT_ID = "contentId"
        const val KEY_STAGE = "stage"
    }
}

/** زمان‌بند یادآور دو مرحله‌ای */
object ReminderScheduler {
    const val CHANNEL_ID = "reminder_channel"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, context.getString(R.string.notify_channel),
                    NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    /** یادآور مرحله n (n=1 یا 2) برای محتوا؛ daysBefore روز قبل از تاریخ انتشار جلالی */
    fun schedule(context: Context, contentId: Long, title: String,
                 daysBefore: Int, hour: Int, triggerAtMillis: Long, stage: Int) {
        val delay = triggerAtMillis - System.currentTimeMillis()
        if (delay <= 0) return
        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf(
                ReminderWorker.KEY_CONTENT_ID to contentId,
                ReminderWorker.KEY_STAGE to stage))
            .addTag("reminder_$contentId")
            .build()
        WorkManager.getInstance(context)
            .enqueueUniqueWork("reminder_${contentId}_stage$stage", ExistingWorkPolicy.REPLACE, request)
    }

    /** لغو همه یادآورهای یک محتوا */
    fun cancel(context: Context, contentId: Long) {
        WorkManager.getInstance(context).cancelUniqueWork("reminder_${contentId}_stage1")
        WorkManager.getInstance(context).cancelUniqueWork("reminder_${contentId}_stage2")
    }
}
