package ir.omrano.mohtavayeman.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ContentDao {
    @Query("SELECT * FROM contents ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<Content>>

    @Query("SELECT * FROM contents WHERE id = :id")
    fun observeById(id: Long): Flow<Content?>

    @Query("SELECT * FROM contents WHERE id = :id")
    suspend fun getById(id: Long): Content?

    @Query("""SELECT * FROM contents
        WHERE (title LIKE '%' || :q || '%' OR description LIKE '%' || :q || '%')
        ORDER BY createdAt DESC""")
    fun search(q: String): Flow<List<Content>>

    @Query("SELECT * FROM contents WHERE publish_year = :y AND publish_month = :m")
    fun observeByJalaliMonth(y: Int, m: Int): Flow<List<Content>>

    @Insert suspend fun insert(c: Content): Long
    @Update suspend fun update(c: Content)
    @Delete suspend fun delete(c: Content)
}

@Dao
interface ChecklistDao {
    @Query("SELECT * FROM checklist_items WHERE contentId = :contentId ORDER BY `order`, id")
    fun observeForContent(contentId: Long): Flow<List<ChecklistItem>>

    @Insert suspend fun insertAll(items: List<ChecklistItem>)
    @Insert suspend fun insert(item: ChecklistItem): Long
    @Update suspend fun update(item: ChecklistItem)
    @Delete suspend fun delete(item: ChecklistItem)
}

@Dao
interface IdeaDao {
    @Query("SELECT * FROM ideas ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<Idea>>

    @Query("SELECT * FROM ideas WHERE text LIKE '%' || :q || '%' ORDER BY createdAt DESC")
    fun search(q: String): Flow<List<Idea>>

    @Insert suspend fun insert(idea: Idea): Long
    @Delete suspend fun delete(idea: Idea)
}
