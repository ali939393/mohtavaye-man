package ir.omrano.mohtavayeman.ui.screens

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.flow.MutableStateFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.omrano.mohtavayeman.data.AppDatabase
import ir.omrano.mohtavayeman.data.Content
import ir.omrano.mohtavayeman.ui.OmranoCard
import ir.omrano.mohtavayeman.ui.theme.Orange
import ir.omrano.mohtavayeman.util.JalaliDate
import ir.omrano.mohtavayeman.util.JalaliUtils
import ir.omrano.mohtavayeman.vm.ContentRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn

@OptIn(ExperimentalCoroutinesApi::class)
class CalendarViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ContentRepository(AppDatabase.getInstance(app))
    private val today = JalaliUtils.today()
    private val _month = MutableStateFlow(today.year to today.month)
    val month: StateFlow<Pair<Int, Int>> = _month

    val contents: StateFlow<List<Content>> = _month
        .flatMapLatest { (y, m) -> repo.byJalaliMonth(y, m) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun prevMonth() {
        val (y, m) = _month.value
        _month.value = if (m == 1) y - 1 to 12 else y to m - 1
    }

    fun nextMonth() {
        val (y, m) = _month.value
        _month.value = if (m == 12) y + 1 to 1 else y to m + 1
    }

    fun goToday() { _month.value = today.year to today.month }
}

/** صفحه تقویم جلالی با نمایش روزهای انتشار محتوا */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarScreen(vm: CalendarViewModel = viewModel()) {
    val (year, month) = vm.month.collectAsState().value
    val contents by vm.contents.collectAsState()
    val today = remember { JalaliUtils.today() }
    var selectedDay by remember { mutableStateOf<Int?>(null) }

    val byDay = remember(contents) { contents.associateBy { it.publishDay ?: -1 } }
    val daysInMonth = JalaliUtils.monthLength(year, month)
    val firstWeekDay = remember(year, month) { JalaliUtils.dayOfWeek(year, month, 1) }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        // ناوبری ماه
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = vm::prevMonth) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "ماه قبل")
            }
            Text(
                "${JalaliUtils.monthNames[month - 1]} $year",
                style = MaterialTheme.typography.titleLarge,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = vm::nextMonth) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "ماه بعد")
            }
        }
        TextButton(onClick = { vm.goToday(); selectedDay = today.day }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text("امروز: ${today}")
        }
        Spacer(Modifier.height(8.dp))

        // سرستون روزهای هفته
        Row(Modifier.fillMaxWidth()) {
            JalaliUtils.weekDays.forEach { d ->
                Text(
                    d, textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        Spacer(Modifier.height(4.dp))

        // شبکه روزها
        val cells = firstWeekDay + daysInMonth
        val rows = (cells + 6) / 7
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            repeat(rows) { r ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    repeat(7) { c ->
                        val index = r * 7 + c
                        val day = index - firstWeekDay + 1
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            if (day in 1..daysInMonth) {
                                val content = byDay[day]
                                val isToday = today.year == year && today.month == month && today.day == day
                                DayCell(
                                    day = day,
                                    isToday = isToday,
                                    hasContent = content != null,
                                    isRest = content?.restDay == true,
                                    selected = selectedDay == day,
                                    onClick = { selectedDay = if (selectedDay == day) null else day }
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // جزئیات روز انتخاب‌شده
        val selectedContent = selectedDay?.let { byDay[it] }
        when {
            selectedDay == null -> Text(
                "روی یک روز ضربه بزنید تا محتوای آن روز دیده شود.",
                style = MaterialTheme.typography.bodyMedium
            )
            selectedContent == null -> Text(
                "محتوایی برای $selectedDay ${JalaliUtils.monthNames[month - 1]} ثبت نشده است.",
                style = MaterialTheme.typography.bodyMedium
            )
            else -> OmranoCard {
                Text(selectedContent.title, style = MaterialTheme.typography.titleMedium)
                if (selectedContent.description.isNotBlank())
                    Text(selectedContent.description, style = MaterialTheme.typography.bodyMedium)
                Text(
                    if (selectedContent.restDay) "روز استراحت" else "روز انتشار",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (selectedContent.restDay) MaterialTheme.colorScheme.tertiary else Orange
                )
            }
        }
    }
}

@Composable
private fun DayCell(
    day: Int,
    isToday: Boolean,
    hasContent: Boolean,
    isRest: Boolean,
    selected: Boolean,
    onClick: () -> Unit
) {
    val bg = when {
        selected -> MaterialTheme.colorScheme.primary
        isToday -> MaterialTheme.colorScheme.secondaryContainer
        else -> MaterialTheme.colorScheme.surface
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(2.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(34.dp)
                .background(bg, CircleShape)
        ) {
            Text(
                day.toString(),
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
        }
        if (hasContent) {
            Box(
                Modifier
                    .padding(top = 2.dp)
                    .size(6.dp)
                    .background(if (isRest) MaterialTheme.colorScheme.tertiary else Orange, CircleShape)
            )
        } else {
            Spacer(Modifier.height(8.dp))
        }
    }
}
