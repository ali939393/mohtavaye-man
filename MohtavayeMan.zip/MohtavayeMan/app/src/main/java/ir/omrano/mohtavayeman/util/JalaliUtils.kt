package ir.omrano.mohtavayeman.util

import java.util.Calendar
import java.util.Locale

data class JalaliDate(val year: Int, val month: Int, val day: Int) {
    override fun toString() = String.format(Locale.US, "%d/%02d/%02d", year, month, day)
    val monthName: String get() = JalaliUtils.monthNames[month - 1]
}

object JalaliUtils {
    val monthNames = listOf(
        "فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور",
        "مهر","آبان","آذر","دی","بهمن","اسفند"
    )
    val weekDays = listOf("ش","ی","د","س","چ","پ","ج")

    private fun div(a: Int, b: Int) = a / b

    fun gregorianToJalali(gy: Int, gm: Int, gd: Int): JalaliDate {
        val g_d_m = intArrayOf(0,31,59,90,120,151,181,212,243,273,304,334)
        var jy = if (gy <= 1600) 0 else 979
        var gy2 = if (gy <= 1600) gy - 621 else gy - 1600
        val gy3 = if (gm > 2) gy2 + 1 else gy2
        var days = 365L * gy2 + div(gy3 + 3, 4) - div(gy3 + 99, 100) +
                div(gy3 + 399, 400) - 80 + gd + g_d_m[gm - 1]
        jy += 33 * div(days.toInt(), 12053)
        days %= 12053
        jy += 4 * div(days.toInt(), 1461)
        days %= 1461
        if (days > 365) {
            jy += div((days - 1).toInt(), 365)
            days = (days - 1) % 365
        }
        val jm: Int; val jd: Long
        if (days < 186) { jm = 1 + div(days.toInt(), 31); jd = 1 + (days % 31) }
        else { jm = 7 + div((days - 186).toInt(), 30); jd = 1 + ((days - 186) % 30) }
        return JalaliDate(jy, jm, jd.toInt())
    }

    fun jalaliToGregorian(jy: Int, jm: Int, jd: Int): Triple<Int, Int, Int> {
        var gy = if (jy > 979) 1600 else 621
        val jy2 = if (jy > 979) jy - 979 else jy
        var days = 365L * jy2 + div(jy2, 33) * 8 + div(jy2 % 33 + 3, 4) + 78 + jd +
                (if (jm < 7) (jm - 1) * 31 else (jm - 7) * 30 + 186)
        gy += 400 * div(days.toInt(), 146097)
        days %= 146097
        if (days > 36524) {
            gy += 100 * div((days - 1).toInt(), 36524)
            days = (days - 1) % 36524
            if (days >= 365) days += 1 else days = days
        }
        gy += 4 * div(days.toInt(), 1461)
        days %= 1461
        if (days > 365) {
            gy += div((days - 1).toInt(), 365)
            days = (days - 1) % 365
        }
        var gd = days + 1
        val sal_a = intArrayOf(0,31, if (gy % 4 == 0 && gy % 100 != 0 || gy % 400 == 0) 29 else 28,31,30,31,30,31,31,30,31,30,31)
        var gm = 0
        while (gm < 13 && gd > sal_a[gm]) { gd -= sal_a[gm]; gm++ }
        return Triple(gy, gm, gd.toInt())
    }

    fun today(): JalaliDate {
        val c = Calendar.getInstance()
        return gregorianToJalali(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    /** روز هفته جلالی: 0=شنبه ... 6=جمعه */
    fun dayOfWeek(jy: Int, jm: Int, jd: Int): Int {
        val (gy, gm, gd) = jalaliToGregorian(jy, jm, jd)
        val c = Calendar.getInstance().apply { set(gy, gm - 1, gd) }
        return (c.get(Calendar.DAY_OF_WEEK) + 1) % 7 // Sunday=1 -> 1 ... Saturday=7 -> 0
    }

    fun isLeap(jy: Int) = intArrayOf(1,5,9,13,17,22,26,30).contains(jy % 33)

    fun monthLength(jy: Int, jm: Int) = when {
        jm <= 6 -> 31
        jm <= 11 -> 30
        else -> if (isLeap(jy)) 30 else 29
    }

    /** تبدیل تاریخ جلالی به زمان‌سنج (میلی‌ثانیه) برای یادآور */
    fun jalaliToMillis(jy: Int, jm: Int, jd: Int, hour: Int, minute: Int): Long {
        val (gy, gm, gd) = jalaliToGregorian(jy, jm, jd)
        val c = Calendar.getInstance().apply { set(gy, gm - 1, gd, hour, minute, 0); set(Calendar.MILLISECOND, 0) }
        return c.timeInMillis
    }
}
