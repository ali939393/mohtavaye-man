package ir.omrano.mohtavayeman.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.omrano.mohtavayeman.ui.OmranoCard
import ir.omrano.mohtavayeman.ui.theme.Orange
import ir.omrano.mohtavayeman.vm.IdeaViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** صفحه ایده‌ها: جست‌وجو، ثبت سریع ایده و حذف */
@Composable
fun IdeasScreen(vm: IdeaViewModel = viewModel()) {
    val ideas by vm.ideas.collectAsState()
    val query by vm.query.collectAsState()
    var quickText by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = vm::setQuery,
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            placeholder = { Text("جست‌وجو در ایده‌ها…") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = quickText,
                onValueChange = { quickText = it },
                placeholder = { Text("ایده جدید…") },
                leadingIcon = { Icon(Icons.Filled.Lightbulb, null, tint = Orange) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f)
            )
            ExtendedFloatingActionButton(
                onClick = {
                    vm.quickAdd(quickText)
                    quickText = ""
                },
                enabled = quickText.isNotBlank(),
                containerColor = Orange,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(4.dp))
                Text("افزودن")
            }
        }
        Spacer(Modifier.height(10.dp))

        if (ideas.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("هنوز ایده‌ای ثبت نشده است ✨", style = MaterialTheme.typography.bodyLarge)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ideas, key = { it.id }) { idea ->
                    OmranoCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Lightbulb, null, tint = Orange)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(idea.text, style = MaterialTheme.typography.bodyLarge)
                                val date = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
                                    .format(Date(idea.createdAt))
                                Text(date, style = MaterialTheme.typography.labelMedium)
                            }
                            IconButton(onClick = { vm.delete(idea) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "حذف")
                            }
                        }
                    }
                }
            }
        }
    }
}
