package ir.omrano.mohtavayeman.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import ir.omrano.mohtavayeman.ui.screens.CalendarScreen
import ir.omrano.mohtavayeman.ui.screens.ContentsScreen
import ir.omrano.mohtavayeman.ui.screens.IdeasScreen
import ir.omrano.mohtavayeman.ui.screens.ContentDetailScreen

private data class TabSpec(val title: String, val icon: ImageVector)

@Composable
fun MohtavayeManAppScreen() {
    var tab by remember { mutableIntStateOf(0) }
    var editingId by remember { mutableStateOf<Long?>(null) }
    val tabs = listOf(
        TabSpec("محتواها", Icons.Filled.ListAlt),
        TabSpec("ایده‌ها", Icons.Filled.Lightbulb),
        TabSpec("تقویم", Icons.Filled.CalendarMonth),
    )
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tabs[tab].title) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                )
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, spec ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Icon(spec.icon, contentDescription = spec.title) },
                        label = { Text(spec.title) },
                    )
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (tab) {
                0 -> ContentsScreen(onOpenDetail = { editingId = it })
                1 -> IdeasScreen()
                2 -> CalendarScreen()
            }
        }
    }
    editingId?.let { id ->
        ContentDetailScreen(
            contentId = id,
            onDismiss = { editingId = null }
        )
    }
}
