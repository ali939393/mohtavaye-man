package ir.omrano.mohtavayeman.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [Content::class, ChecklistItem::class, Idea::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(ChecklistConverter::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun contentDao(): ContentDao
    abstract fun checklistDao(): ChecklistDao
    abstract fun ideaDao(): IdeaDao

    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext, AppDatabase::class.java, "mohtavayeman.db"
                ).fallbackToDestructiveMigration().build().also { instance = it }
            }
    }
}
