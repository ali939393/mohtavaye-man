package ir.omrano.mohtavayeman

import android.app.Application
import androidx.work.Configuration
import ir.omrano.mohtavayeman.data.AppDatabase
import ir.omrano.mohtavayeman.work.ReminderScheduler

class MohtavayeManApp : Application(), Configuration.Provider {
    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }

    override fun onCreate() {
        super.onCreate()
        ReminderScheduler.ensureChannel(this)
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder().build()
}
