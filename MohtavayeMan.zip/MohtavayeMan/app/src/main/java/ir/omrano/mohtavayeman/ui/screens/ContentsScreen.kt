package ir.omrano.mohtavayeman.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.omrano.mohtavayeman.data.Content
import ir.omrano.mohtavayeman.ui.OmranoCard
import ir.omrano.mohtavayeman.ui.theme.Orange
import ir.omrano.mohtavayeman.vm.ContentViewModel

@Composable
fun ContentsScreen(vm: ContentViewModel = viewModel(), onOpenDetail: (Long) -> Unit) {
    val contents by vm.contents.collectAsState()
    val query by vm.query.collectAsState()
    var showAdd by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(14.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = vm::setQuery,
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "جست‌وجو") },
                placeholder = { Text("جست‌وجو در محتواها…") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(Modifier.height(10.dp))
            if (contents.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (query.isBlank()) "هنوز محتوایی ثبت نشده است." else "محتوایی پیدا نشد.")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 88.dp)
                ) {
                    items(contents, key = { it.id }) { content ->
                        OmranoCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(
                                    Modifier.weight(1f).clickable { onOpenDetail(content.id) }
                                ) {
                                    Text(content.title, style = MaterialTheme.typography.titleMedium)
                                    val date = if (content.publishYear != null && content.publishMonth != null && content.publishDay != null)
                                        "${content.publishYear}/${content.publishMonth.toString().padStart(2, '0')}/${content.publishDay.toString().padStart(2, '0')}"
                                    else "بدون تاریخ"
                                    Text(
                                        if (content.restDay) "روز استراحت • $date" else "روز فعال • $date",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (content.restDay) MaterialTheme.colorScheme.tertiary else Orange
                                    )
                                }
                                IconButton(onClick = { vm.delete(content) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "حذف")
                                }
                            }
                        }
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { showAdd = true },
            containerColor = Orange,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.align(Alignment.BottomEnd).padding(18.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("محتوای جدید")
        }
    }

    if (showAdd) {
        ContentEditorDialog(onDismiss = { showAdd = false }, onSave = { content ->
            vm.save(content)
            showAdd = false
        })
    }
}

@Composable
fun ContentEditorDialog(
    initial: Content? = null,
    onDismiss: () -> Unit,
    onSave: (Content) -> Unit
) {
    var title by remember(initial?.id) { mutableStateOf(initial?.title ?: "") }
    var desc by remember(initial?.id) { mutableStateOf(initial?.description ?: "") }
    var y by remember(initial?.id) { mutableStateOf(initial?.publishYear?.toString() ?: "") }
    var m by remember(initial?.id) { mutableStateOf(initial?.publishMonth?.toString() ?: "") }
    var d by remember(initial?.id) { mutableStateOf(initial?.publishDay?.toString() ?: "") }
    var rest by remember(initial?.id) { mutableStateOf(initial?.restDay ?: false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "محتوای جدید" else "ویرایش محتوا") },
        confirmButton = {
            TextButton(enabled = title.isNotBlank(), onClick = {
                val year = y.toIntOrNull()
                val month = m.toIntOrNull()
                val day = d.toIntOrNull()
                val validDate = (year == null && month == null && day == null) ||
                    (year != null && month != null && month in 1..12 && day != null && day in 1..31)
                if (validDate) onSave(Content(
                    id = initial?.id ?: 0,
                    title = title.trim(),
                    description = desc.trim(),
                    publishYear = year,
                    publishMonth = month,
                    publishDay = day,
                    restDay = rest
                ))
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it },
                    label = { Text("عنوان") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = desc, onValueChange = { desc = it },
                    label = { Text("توضیحات") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = y, onValueChange = { y = it.filter(Char::isDigit) },
                        label = { Text("سال (جلالی)") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = m, onValueChange = { m = it.filter(Char::isDigit) },
                        label = { Text("ماه") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = d, onValueChange = { d = it.filter(Char::isDigit) },
                        label = { Text("روز") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = rest, onCheckedChange = { rest = it })
                    Text("روز استراحت (نه انتشار)")
                }
            }
        }
    )
}
