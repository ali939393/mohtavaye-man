package ir.omrano.mohtavayeman.vm

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.omrano.mohtavayeman.data.AppDatabase
import ir.omrano.mohtavayeman.data.ChecklistItem
import ir.omrano.mohtavayeman.data.Content
import ir.omrano.mohtavayeman.data.Idea
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ContentViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ContentRepository(AppDatabase.getInstance(app))
    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    val contents: StateFlow<List<Content>> = _query
        .flatMapLatest { q -> if (q.isBlank()) repo.all() else repo.search(q) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setQuery(q: String) { _query.value = q }

    fun save(content: Content, checklistTexts: List<String>? = null, onDone: (Long) -> Unit = {}) =
        viewModelScope.launch { onDone(repo.save(getApplication(), content, checklistTexts)) }

    fun delete(content: Content) = viewModelScope.launch { repo.delete(getApplication(), content) }
}

@OptIn(ExperimentalCoroutinesApi::class)
class ContentDetailViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.getInstance(app)
    private val repo = ContentRepository(db)

    private val contentId = MutableStateFlow(0L)
    val content: StateFlow<Content?> = contentId
        .flatMapLatest { id -> if (id == 0L) flowOf(null) else db.contentDao().observeById(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val checklist: StateFlow<List<ChecklistItem>> = contentId
        .flatMapLatest { id ->
            if (id == 0L) flowOf(emptyList()) else db.checklistDao().observeForContent(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun load(id: Long) { contentId.value = id }

    fun toggle(item: ChecklistItem) = viewModelScope.launch { repo.toggleItem(item) }
    fun add(text: String) = viewModelScope.launch { repo.addItem(contentId.value, text) }
    fun remove(item: ChecklistItem) = viewModelScope.launch { repo.removeItem(item) }
    fun reschedule(content: Content) = viewModelScope.launch {
        repo.scheduleReminders(getApplication(), content)
    }
}

class IdeaViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = IdeaRepository(AppDatabase.getInstance(app))
    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    val ideas: StateFlow<List<Idea>> = _query
        .flatMapLatest { q -> if (q.isBlank()) repo.all() else repo.search(q) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setQuery(q: String) { _query.value = q }
    fun quickAdd(text: String) = viewModelScope.launch { repo.quickAdd(text) }
    fun delete(idea: Idea) = viewModelScope.launch { repo.delete(idea) }
}
